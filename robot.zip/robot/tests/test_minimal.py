from robot.minimal import execute_command
from robot.minimal import Robot
from robot.minimal import minimal
from robot import Direction
import tempfile


def test_robot_commands():

    seen = set([])
    robot = Robot(0, 0, seen)
    execute_command(Direction.E, 2, robot)
    assert len(robot.seen) == 2
    execute_command(Direction.N, 1, robot)
    assert len(robot.seen) == 3
    execute_command(Direction.S, 1, robot)
    assert len(robot.seen) == 3
    execute_command(Direction.W, 2, robot)
    assert len(robot.seen) == 4


def test_app():
    EXAMPLE = """2
10 22
E 2
N 1
"""
    file = tempfile.NamedTemporaryFile()
    with open(file.name, "w") as f:
        f.write(EXAMPLE)

    result = minimal(data=file.name)
    assert result == "=> Cleaned: 4"
