from robot import UniquePosVisitor
from robot import Robot
from robot import RobotProtocol
from robot import IRobot
from robot import IVisitor
from robot import Direction
from robot import run
import tempfile
import typing


def test_uniquepostracker():
    visitor = UniquePosVisitor()
    visitor.visit((0, 1))
    visitor.visit((0, 2))
    visitor.visit((0, 1))

    stats = visitor.stats()
    assert stats["unique_visits"] == 2


# expected, movements
ROBOT_POS = [
    [(-1, 0), ("W", 1)],
    [(-10, 0), ("W", 10)],
    [(0, 0), ("W", 10), ("E", 10)],
    [(0, -10), ("W", 10), ("E", 10), ("N", 10)],
    [(0, 0), ("W", 10), ("E", 10), ("N", 10), ("S", 10)],
    [(2, -1), ("E", 2), ["N", 1]],  # provided test case
]

# unique visited
ROBOT_VISITED = [2, 11, 11, 21, 21, 4]


class DummyVisitor(IVisitor):
    """ Does nothing, it's prupose its to test the robot without visitors """

    def visit(self, position: typing.Tuple[int, int]):
        pass

    def stats(self):
        return {}


def test_robot_tracks_position():
    for items in ROBOT_POS:
        r = Robot(DummyVisitor())
        r.initialize(0, 0)
        expected, *commands = items
        steps = 0
        for cmd in commands:
            # we track steps to be able to ensure
            # robot is keeping it's state in sync
            steps += abs(cmd[1])
            r.execute_command(cmd[0], cmd[1])
        assert expected == (r.posx, r.posy)
        assert len(commands) == r.num_commands
        assert r.steps == steps
        # only for coverage
        assert r.visitor.stats() == {}


def test_robot_unique_visitor():
    for idx, items in enumerate(ROBOT_POS):
        visitor = UniquePosVisitor()
        r = Robot(visitor=visitor)
        r.initialize(0, 0)
        _, *commands = items
        for cmd in commands:
            r.execute_command(cmd[0], cmd[1])
        assert ROBOT_VISITED[idx] == len(visitor.pos), f"failed {idx}"


class RobotRecorder(IRobot):
    def __init__(self):
        self.posx = 0
        self.posy = 1
        self.commands = []

    def initialize(self, posx: int, posy: int):
        self.posx = posx
        self.posy = posy

    def execute_command(self, command: Direction, steps: int):
        self.commands.append((command, steps))


class DummyLogger:
    def __init__(self):
        self.log = None

    def info(self, message):
        self.log = message


def test_robot_protocol():
    recorder = RobotRecorder()
    logger = DummyLogger()
    proto = RobotProtocol(robot=recorder, logger=logger)
    proto.on_receive("2\n")
    assert proto.state == proto.STATE_CORDINATES
    assert proto.expected_commands == 2
    proto.on_receive("10 22\n")
    assert proto.state == proto.STATE_WORKING
    assert proto.current_command == 0
    assert proto.initial_pos == (10, 22)
    proto.on_receive("E 2\n")
    assert proto.state == proto.STATE_WORKING
    assert proto.current_command == 1
    assert len(recorder.commands) == 1
    assert recorder.commands[0] == (Direction.E, 2)
    proto.on_receive("N 1\n")
    assert proto.state == proto.STATE_STOPPED
    assert proto.current_command == 2
    assert len(recorder.commands) == 2
    assert recorder.commands[1] == (Direction.N, 1)
    proto.on_receive("N 1\n")
    assert proto.state == proto.STATE_STOPPED
    assert proto.current_command == 2
    assert len(recorder.commands) == 2
    assert recorder.commands[1] == (Direction.N, 1)
    assert logger.log == "invalid_protocol"


def test_e2e(monkeypatch):
    EXAMPLE = """2
10 22
E 2
N 1
"""
    file = tempfile.NamedTemporaryFile()
    with open(file.name, "w") as f:
        f.write(EXAMPLE)

    result = run(data=file.name)
    assert result == "=> Cleaned: 4"
