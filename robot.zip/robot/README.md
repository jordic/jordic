# ROBOT

There are two apporaches:

- `robot/__init__.py`

  OOP Based. There are two contracts plus a protocol.

  - IRobot. It's the contract for the robot, it initializes, and executes_commands
  - IVisitor. it provides a visit (that it's called through) the robot,
    on every step it does.
  - RobotProtocol, it's a minimal state machine, (without error checking),
    that parses the protocol, and executes commands on the entity.
    Perhaps a better name could be RobotController, but I named robot protocol
    because it's main responsability is to parse, and delegate found actions.
    (Initialize, execute_command, and stop when it's done, oveys max commands
    provided on intialitzation)

  - It tries to enforce composition over inheritance.

- `robot/minimal.py` it's a minimal approach, that also works.

  - It's mostly a robot entity, with a set inside to track seen rows
    (the prupose of the task). Protocol parsing it's implementing through
    the entry_point, `minimal`. It keeps things coupled, but it's
    enought easy to evolve it and mantain it.

  - I added it to emphatize that sometimes a simpler approach,
    with less code, it's easy to mantain over time.

Which one I prefer? It depends! On the context, the resubility, there are
tons of factors to implement somthing on one way or on another one.

And also, perhaps I'm completly wrong and this needs
to evolve to something else. Let's review it!
(I have the feeling that I have evolved it to much without peer reviewing,
I'm used to evolve things and make decisions as a team, but right, on this
example, I'm single person team.)

## RUN it

I tried to build it following best python practices.
A python package, with tests outside.

There are no dependencies for running the robot. But I choosed pytest,
to manage testing. Every file inside robot, should run as is.
I went with pytest because it's a so good evolution around testing
on python, language assertion, and a good ecosystem of modules.
I picked pytest-cov to build a coverage report around it.

```bash
extract the zip file
cd robot/
python3.8 -m venv env
pip install -e .[test]

```

There's also a fixture.txt with the provided example, it can be run with:

```
cat fixture.txt | python3.8 robot/__init__.py
```

the minimal impl.

```
cat fixture.txt | python3.8 robot/minimal.py
```

Run tests

```
pytest tests/
```

Mypy

```
mypy robot/
```

### Coverage:

```
pytest --cov robot/ tests/
```

with a report

```
pytest --cov-report html -cov=robot/ tests/
```
