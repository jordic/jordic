import typing
from abc import abstractmethod
from enum import Enum
from typing import Protocol


class IVisitor(Protocol):
    """
    The contract that our robot will use to notify it's cordinates
    It could be a uniquevistortracker, a gps tracker,
    or a multitracker (With a MultiVisitor that notifies
    every registered visitor, implementing an event dispatching
    with pubsub.
    """

    @abstractmethod
    def visit(self, position: typing.Tuple[int, int]):
        pass


class IRobot(Protocol):
    """An Abstract IRobot, initializes to a
    given position, and executes commands.
    That's the minium contract for a robot"""

    @abstractmethod
    def initialize(self, posx: int, posy: int):
        """ Initializes the robot at a given position """
        pass

    @abstractmethod
    def execute_command(self, command: "Direction", steps: int):
        """ Executes a command on the robot """
        pass


class UniquePosVisitor(IVisitor):
    """ A Visitor that uses a set to track visited positions """

    def __init__(self):
        self.pos: typing.Set[typing.Tuple[int, int]] = set()

    def visit(self, position: typing.Tuple[int, int]):
        self.pos.add(position)

    def stats(self):
        return {"unique_visits": len(self.pos)}


class Direction(str, Enum):
    N = "N"  # Y - 1
    E = "E"  # X + 1
    S = "S"  # Y + 1
    W = "W"  # Y - 1


class Robot(IRobot):
    """A robot implementation that has a visitor
    for reporting its position.
    It's main function is to receive a commands
    and execute every provided step on the command.
    """

    def __init__(self, visitor: "IVisitor"):
        self.posx: int = 0
        self.posy: int = 0
        self.visitor: IVisitor = visitor
        self.num_commands: int = 0
        self.steps: int = 0

    def initialize(self, posx: int, posy: int):
        self.posx = posx
        self.posy = posy
        self.visitor.visit((self.posx, self.posy))

    def execute_command(self, command: Direction, steps: int):
        dy: int = 0
        dx: int = 0
        # going north is decreasing Y - 1
        if command == Direction.N:
            dy = -1
        elif command == Direction.S:
            dy = 1
        elif command == Direction.E:
            dx = 1
        elif command == Direction.W:
            dx = -1

        for _ in range(steps):
            self.posx += dx
            self.posy += dy
            self.visitor.visit((self.posx, self.posy))
            self.steps += 1
        self.num_commands += 1


class RobotProtocol:
    """This is a rude and simple text line protocol
    impl for managing the robot. It follows the
    sansIO approach, IO it's managed outside, it could be
    a feed over text or over socket.
    It's mostly a state machine
    """

    STATE_INIT = "init"  # robot initialized
    STATE_CORDINATES = "ncoord"  # expecting coordinations after
    STATE_WORKING = "working"  # robot is working
    STATE_STOPPED = "stopped"  # robot has finished working

    def __init__(self, robot: IRobot, logger=None):
        self.state = self.STATE_INIT
        self.robot: IRobot = robot
        self.expected_commands = None
        self.current_command = 0
        self.initial_pos: typing.Tuple[int, int] = (0, 0)
        self.logger = logger
        self.log("robot protocol initialized")

    def on_receive(self, line):
        if self.state == self.STATE_INIT:
            self.parse_expected_commands(line)
            self.state = self.STATE_CORDINATES
        elif self.state == self.STATE_CORDINATES:
            self.parse_position(line)
            self.robot.initialize(*self.initial_pos)
            self.state = self.STATE_WORKING
        elif self.state == self.STATE_WORKING:
            self.execute_command(line)
            if self.current_command == self.expected_commands:
                self.state = self.STATE_STOPPED
        elif self.state == self.STATE_STOPPED:
            self.log("invalid_protocol")

    def parse_expected_commands(self, line):
        self.expected_commands = int(line.rstrip())

    def parse_position(self, line):
        parts = line.rstrip().split(" ")
        items = [int(p) for p in parts]
        self.initial_pos = tuple(items)

    def execute_command(self, line):
        command, steps = line.rstrip().split(" ")
        steps = int(steps)
        self.robot.execute_command(command, steps)
        self.current_command += 1

    def log(self, message):
        if self.logger:
            self.logger.info(message)


def run(data=None):
    """
    We can go further, that's a minimal robot controller,
    without reporting, or just with stdout reporting
    If we one to go further, we can implement a RobotController
    for example if we want to have a daemon that receives
    orders over a socket.
    BTW for the scope of the task, I think it's enough.
    """
    import fileinput

    visitor = UniquePosVisitor()
    robot = Robot(visitor=visitor)
    protocol = RobotProtocol(robot)
    for line in fileinput.input(data):
        protocol.on_receive(line)

    stats = visitor.stats()
    return f"=> Cleaned: {stats['unique_visits']}"


if __name__ == "__main__":
    print(run())
