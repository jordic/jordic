import fileinput
import typing
from dataclasses import dataclass
from enum import Enum


class Direction(str, Enum):
    N = "N"
    E = "E"
    S = "S"
    W = "W"


class State:
    INIT = "init"  # robot initialized
    CORDINATES = "ncoord"  # expecting coordinations after
    WORKING = "working"  # robot is working
    STOPPED = "stopped"  # stopped


@dataclass
class Robot:
    posx: int
    posy: int
    seen: typing.Set


def parse_command(line):
    command, steps = line.rstrip().split(" ")
    return command, int(steps)


def execute_command(command: Direction, steps: int, robot: "Robot"):
    dy: int = 0
    dx: int = 0
    if command == Direction.N:
        dy = -1
    elif command == Direction.S:
        dy = 1
    elif command == Direction.E:
        dx = 1
    elif command == Direction.W:
        dx = -1
    for _ in range(steps):
        robot.posx += dx
        robot.posy += dy
        robot.seen.add((robot.posx, robot.posy))


def minimal(data=None):
    state = State.INIT
    max_commands: int = 0
    executed: int = 0
    robot = None
    for line in fileinput.input(data):
        if state == State.INIT:
            max_commands = int(line.rstrip())
            state = State.CORDINATES
        elif state == State.CORDINATES:
            parts = line.rstrip().split(" ")
            posx, posy = [int(p) for p in parts]
            robot = Robot(posx, posy, set([]))
            state = State.WORKING
            robot.seen.add((posx, posy))
        elif state == State.WORKING:
            cmd, steps = parse_command(line)
            execute_command(cmd, steps, robot)
            executed += 1
            if max_commands == executed:
                state = State.STOPPED
    return f"=> Cleaned: {len(robot.seen)}"


if __name__ == "__main__":
    print(minimal())
