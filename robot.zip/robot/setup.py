from setuptools import find_packages
from setuptools import setup


try:
    README = open("README.md").read()
except IOError:
    README = None

setup(
    name="robot",
    version="0.0.0",
    description="A robot",
    long_description=README,
    author="jordi collell",
    author_email="jordic@gmail.com",
    url="",
    packages=find_packages(),
    include_package_data=True,
    tests_require=["pytest", "mypy", "pytest-cov"],
    extras_require={"test": ["pytest"]},
    classifiers=[],
    entry_points={},
)
